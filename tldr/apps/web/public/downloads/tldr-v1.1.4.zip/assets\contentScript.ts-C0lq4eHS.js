import{s as yt,H as k,E as w,B,c as $,n as P,a as Q,w as Et,d as Ct,D as St,e as Rt,b as It,f as wt}from"./settings-BheiT25R.js";import{l as m,r as L,c as it,w as F}from"./logger-Oy_tsM0_.js";var Tt=["article","main","[role='main']",".article",".post",".content"],vt=["script","style","noscript","textarea","input","select","option","button","code","pre","[contenteditable='true']"];function Nt(t){return t?t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement?!0:t instanceof HTMLElement?t.isContentEditable:!1:!1}function K(t){for(const e of Tt){const s=t.querySelector(e);if(s&&s.textContent&&s.textContent.trim().length>200)return s}return t.body}function Lt(t){const e=[],s=[],n=(t.ownerDocument??document).createTreeWalker(t,NodeFilter.SHOW_TEXT,{acceptNode(l){if(!l.nodeValue||!l.nodeValue.trim())return NodeFilter.FILTER_REJECT;const u=l.parentElement;return!u||vt.some(h=>u.closest(h))||Nt(u)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}});let i=n.nextNode(),o=0,a=!1,c=!1,d=!1;function f(){!c||a||(s.push(" "),o+=1,a=!0)}function x(l,u,h){const p=e[e.length-1];p&&p.node===l&&p.end===o&&p.nodeOffset+(p.end-p.start)===u?p.end+=1:e.push({node:l,start:o,end:o+1,nodeOffset:u}),s.push(h),o+=1,a=!1,c=!0}for(;i;){const l=i,u=l.nodeValue??"";if(u.length>0){e.length>0&&(d=!0);for(let h=0;h<u.length;h+=1){const p=u[h]??"";if(/\s/.test(p)){d=!0;continue}d&&(f(),d=!1),x(l,h,p)}d=!0}i=n.nextNode()}return a&&s.length>0&&s[s.length-1]===" "&&s.pop(),{text:s.join(""),nodes:e}}function W(t){return Lt(t)}function A(t,e,s){var c,d,f,x;if(!t.length)return null;const r=((d=(c=t[0])==null?void 0:c.node.ownerDocument)==null?void 0:d.createRange())??document.createRange();let n,i;for(const l of t)if(!n&&e>=l.start&&e<l.end&&(n=l),s>l.start&&s<=l.end){i=l;break}if(n||(n=t.find(l=>l.start>e),e=(n==null?void 0:n.start)??e),!i)for(let l=t.length-1;l>=0;l-=1){const u=t[l];if(s>=u.end){i=u,s=u.end;break}}if(!n||!i)return null;const o=Math.max(0,n.nodeOffset+(e-n.start)),a=Math.max(0,i.nodeOffset+(s-i.start));return r.setStart(n.node,Math.min(o,((f=n.node.nodeValue)==null?void 0:f.length)??o)),r.setEnd(i.node,Math.min(a,((x=i.node.nodeValue)==null?void 0:x.length)??a)),r}function Ht(t,e){const s=e.startContainer,r=e.endContainer;if(!(s instanceof Text)||!(r instanceof Text))return null;const n=t.find(o=>o.node===s&&e.startOffset>=o.nodeOffset&&e.startOffset<=o.nodeOffset+(o.end-o.start)),i=t.find(o=>o.node===r&&e.endOffset>=o.nodeOffset&&e.endOffset<=o.nodeOffset+(o.end-o.start));return!n||!i?null:{start:n.start+(e.startOffset-n.nodeOffset),end:i.start+(e.endOffset-i.nodeOffset)}}const Y="tldr-highlight-sentences",j="tldr-highlight-keywords",X="tldr-highlight-rsvp-cursor",at="data-tldr-highlight",Ot="tldr-inline-popover",y="tldr-floating-bubble",J="data-tldr-embolden",lt="tldr-embolden",Z="data-tldr-rsvp-cursor",ct="tldr-rsvp-cursor",H="tldr-deemphasize",_="--tldr-deemphasis-color",R="--tldr-base-color",tt=200;let C=[],E="",O=0,g=[],q=null,D=null,et=!1,b=null,nt=!1,V=!1,z=wt,v=St,U=It,st=!1,S=null;function Mt(){const t={type:"ContentReady",requestId:it("content-ready")};m("cs","ContentReady",{href:location.href}),chrome.runtime.sendMessage(t,()=>L("cs","ContentReady sendMessage"))}function At(){D&&window.clearTimeout(D),D=window.setTimeout(()=>{I()},750)}function I(){const t=K(document),{text:e,nodes:s}=W(t);C=s,E=e,O=Et(e),m("cs","refreshNodes",{nodes:C.length,root:t.tagName,words:O}),G()}function dt(){if(et)return;const t=document.createElement("style");t.textContent=`
    ::highlight(${Y}) {
      background-color: rgba(249, 116, 75, 0.28);
    }

    ::highlight(${j}) {
      background-color: transparent;
      color: var(${R});
      text-shadow: 0.35px 0 0 currentColor, -0.35px 0 0 currentColor;
    }

    ::highlight(${X}) {
      background-color: rgba(249, 116, 75, 0.22);
      text-decoration: underline;
      text-decoration-thickness: 2px;
      text-decoration-color: rgba(249, 116, 75, 0.85);
      text-underline-offset: 2px;
    }

    .${lt}[${J}] {
      color: var(${R});
      text-shadow: 0.35px 0 0 currentColor, -0.35px 0 0 currentColor;
    }

    .${ct}[${Z}] {
      position: relative;
      background-color: rgba(249, 116, 75, 0.22);
      border-radius: 3px;
    }

    .${H},
    .${H} * {
    color: var(${_});
    }
  `,document.head.appendChild(t),et=!0}function ut(){"highlights"in CSS&&CSS.highlights.delete(X);const t=[];S?t.push(S):"highlights"in CSS||t.push(...document.querySelectorAll(`span[${Z}]`)),t.forEach(e=>{e.isConnected&&e.replaceWith(...e.childNodes)}),S=null}function _t(t,e,s,r){ut(),dt(),(!E||!C.length||e>E.length)&&I(),r&&E.slice(t,e)!==r&&I();const n=A(C,t,e);if(n&&!mt(n.commonAncestorContainer)){if(s){const i=n.getBoundingClientRect();if(i.top<0||i.bottom>window.innerHeight){const o=n.startContainer instanceof Element?n.startContainer:n.startContainer.parentElement;o==null||o.scrollIntoView({block:"center",inline:"nearest"})}}if("highlights"in CSS)CSS.highlights.set(X,new Highlight(n));else{const i=document.createElement("span");i.className=ct,i.setAttribute(Z,"true");try{n.surroundContents(i),S=i}catch{S=null}}}}function N(t){if(!t)return;const e=Ct(v);t.style.setProperty("--assist-ext-bg",e.bg),t.style.setProperty("--assist-ext-surface",e.surface),t.style.setProperty("--assist-ext-bg-elevated",e.surface),t.style.setProperty("--assist-ext-surface-soft",`${e.surface}cc`),t.style.setProperty("--assist-ext-border",e.border),t.style.setProperty("--assist-ext-border-soft",`${e.border}99`),t.style.setProperty("--assist-ext-text",e.text),t.style.setProperty("--assist-ext-muted",e.muted),t.style.setProperty("--assist-ext-accent",e.accent),t.style.setProperty("--assist-ext-danger",e.danger)}function kt(){if(nt||!document.body)return;const t=document.createElement("div");t.id=y,t.style.position="fixed",t.style.zIndex="2147483647",t.style.right="18px",t.style.bottom="18px",t.style.display="none",t.style.pointerEvents="auto",document.body.appendChild(t),N(t);const e=t.attachShadow({mode:"open"}),s=document.createElement("style");s.textContent=`
    :host { all: initial; }
    :host {
      --assist-ext-bg: #0a1523;
      --assist-ext-bg-elevated: #193552;
      --assist-ext-surface: #193552cc;
      --assist-ext-border: #2f587f;
      --assist-ext-border-soft: #2f587f99;
      --assist-ext-text: #e0eaf4;
      --assist-ext-muted: #97b1cc;
      --assist-ext-accent: #2f5e8d;
      --assist-ext-radius: 16px;
    }
    .assist-ext-wrap {
      font-family: "Bahnschrift", "Trebuchet MS", "Gill Sans MT", "Segoe UI", sans-serif;
      color: var(--assist-ext-text);
      line-height: 1.45;
    }
    .assist-ext-bubble {
      width: 40px;
      height: 40px;
      border-radius: 14px;
      border: 1px solid var(--assist-ext-border-soft);
      background: color-mix(in srgb, #071a31 74%, transparent);
      color: var(--assist-ext-text);
      cursor: pointer;
      display: grid;
      place-items: center;
      user-select: none;
      font-weight: 600;
      font-size: 12px;
      backdrop-filter: blur(14px);
      box-shadow: 0 16px 34px rgba(1, 10, 24, 0.42);
      transition: transform 120ms ease, box-shadow 120ms ease, border-color 120ms ease, background 120ms ease;
    }
    .assist-ext-bubble img {
      width: 22px;
      height: 22px;
      object-fit: contain;
      display: block;
      pointer-events: none;
    }
    .assist-ext-bubble:hover {
      box-shadow:
        0 0 0 3px color-mix(in srgb, var(--assist-ext-accent) 24%, transparent),
        0 18px 38px rgba(1, 10, 24, 0.5);
    }
    .assist-ext-bubble:active {
      transform: translateY(1px);
      box-shadow:
        inset 0 1px 0 rgba(255, 255, 255, 0.1),
        0 10px 22px rgba(1, 10, 24, 0.32);
    }
    .assist-ext-panel {
      position: absolute;
      right: 0;
      bottom: 52px;
      width: 296px;
      border-radius: calc(var(--assist-ext-radius) + 2px);
      border: 1px solid var(--assist-ext-border-soft);
      background:
        radial-gradient(circle at 0% 0%, color-mix(in srgb, var(--assist-ext-accent) 18%, transparent), transparent 44%),
        linear-gradient(180deg, #0f253d 0%, var(--assist-ext-bg) 52%);
      color: var(--assist-ext-text);
      padding: 12px;
      display: none;
      backdrop-filter: blur(16px);
      box-shadow: 0 24px 52px rgba(1, 10, 24, 0.5);
    }
    .assist-ext-row { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
    .assist-ext-title {
      font-family: "Franklin Gothic Medium", "Arial Narrow", "Trebuchet MS", sans-serif;
      font-weight: 600;
      font-size: 13px;
      letter-spacing: 0.06em;
      text-transform: uppercase;
    }
    .assist-ext-meta { color: var(--assist-ext-muted); font-size: 12px; }
    .assist-ext-btn-row { display: flex; gap: 8px; margin-top: 10px; flex-wrap: wrap; }
    .assist-ext-button {
      border-radius: 999px;
      border: 1px solid var(--assist-ext-border-soft);
      background: color-mix(in srgb, var(--assist-ext-bg-elevated) 62%, transparent);
      color: var(--assist-ext-text);
      padding: 6px 10px;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 8px 18px rgba(0, 0, 0, 0.24);
      transition: transform 120ms ease, box-shadow 120ms ease, border-color 120ms ease, background 120ms ease;
    }
    .assist-ext-button:hover {
      box-shadow:
        0 0 0 3px color-mix(in srgb, var(--assist-ext-accent) 24%, transparent),
        0 12px 26px rgba(1, 10, 24, 0.36);
    }
    .assist-ext-button:active {
      transform: translateY(1px);
      box-shadow:
        inset 0 1px 0 rgba(255, 255, 255, 0.1),
        0 6px 14px rgba(1, 10, 24, 0.28);
    }
    .assist-ext-button:focus-visible {
      outline: 2px solid color-mix(in srgb, var(--assist-ext-accent) 84%, white);
      outline-offset: 2px;
    }
    .assist-ext-button--primary {
      border-color: color-mix(in srgb, var(--assist-ext-accent) 68%, #b8e8ff);
      color: var(--assist-ext-accent);
      font-weight: 600;
    }
  `;const r=document.createElement("div");r.className="assist-ext-wrap";const n=document.createElement("div");n.className="assist-ext-panel",n.setAttribute("role","dialog"),n.setAttribute("aria-label","TLDR reading assistant");const i=document.createElement("div");i.className="assist-ext-row";const o=document.createElement("div");o.className="assist-ext-title",o.textContent="TLDR";const a=document.createElement("button");a.className="assist-ext-button",a.textContent="Close",a.addEventListener("click",h=>{h.preventDefault(),h.stopPropagation(),M(!1)}),i.append(o,a);const c=document.createElement("div");c.className="assist-ext-meta",c.id="tldr-bubble-meta",c.textContent="Detecting page text...";const d=document.createElement("div");d.className="assist-ext-btn-row";const f=document.createElement("button");f.className="assist-ext-button assist-ext-button--primary",f.textContent="Highlight key phrases",f.addEventListener("click",h=>{h.preventDefault(),h.stopPropagation();try{E.trim()||I();const p=Rt(E);bt(p,"keywords")}catch(p){F("cs","Bubble highlight failed",p)}});const x=document.createElement("button");x.className="assist-ext-button",x.textContent="Clear highlights",x.addEventListener("click",h=>{h.preventDefault(),h.stopPropagation(),ft()}),d.append(f,x),n.append(i,c,d);const l=document.createElement("button");l.className="assist-ext-bubble",l.setAttribute("aria-label","Open TLDR");const u=document.createElement("img");u.alt="",u.src=chrome.runtime.getURL("tldr.png"),l.appendChild(u),l.addEventListener("click",h=>{h.preventDefault(),h.stopPropagation(),M(!V)}),r.append(n,l),e.append(s,r),nt=!0}function M(t){var r;V=t;const e=document.getElementById(y),s=(r=e==null?void 0:e.shadowRoot)==null?void 0:r.querySelector(".assist-ext-panel");s&&(s.style.display=V?"block":"none")}function G(){var r,n;kt();const t=document.getElementById(y);if(!t)return;if(!U){t.style.display="none",M(!1);const i=(r=t.shadowRoot)==null?void 0:r.getElementById("tldr-bubble-meta");i&&(i.textContent="Floating bubble is hidden in settings.");return}const e=O>=tt;t.style.display=e?"block":"none",e||M(!1);const s=(n=t.shadowRoot)==null?void 0:n.getElementById("tldr-bubble-meta");s&&(s.textContent=e?`${O.toLocaleString()} words detected on this page.`:`Needs ${tt}+ words to show.`)}function Bt(){q||(q=new MutationObserver(()=>{At()}),q.observe(document.body,{childList:!0,subtree:!0}),m("cs","MutationObserver attached"))}function ft(){g=[],qt(),"highlights"in CSS&&(CSS.highlights.delete(Y),CSS.highlights.delete(j)),document.querySelectorAll(`mark[${at}], span[${J}]`).forEach(t=>t.replaceWith(...t.childNodes))}function ht(t){const e=t.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*,\s*([0-9.]+))?\s*\)/i);if(!e)return null;const s=Number.parseInt(e[1]??"",10),r=Number.parseInt(e[2]??"",10),n=Number.parseInt(e[3]??"",10),i=e[4]!==void 0?Number.parseFloat(e[4]):1;return[s,r,n,i].some(o=>Number.isNaN(o))?null:{r:s,g:r,b:n,a:i}}function pt(t,e){const s=Math.max(0,Math.min(1,e)),r=t.r*.2126+t.g*.7152+t.b*.0722,n=Math.round(Math.max(0,Math.min(255,r*.4+128*.6))),i=Math.round(t.r*(1-s)+n*s),o=Math.round(t.g*(1-s)+n*s),a=Math.round(t.b*(1-s)+n*s);return`rgba(${i}, ${o}, ${a}, ${t.a})`}function gt(){return $(z)/100}function Pt(t){const e=window.getComputedStyle(t),s=ht(e.color);if(!s)return;const r=`rgba(${s.r}, ${s.g}, ${s.b}, ${s.a})`,n=pt(s,gt());t.classList.add(H),t.setAttribute("data-tldr-deemphasize","true"),t.style.setProperty(R,r),t.style.setProperty(_,n),b=t}function rt(){if(!b)return;const t=b;if(!t.isConnected){b=null;return}const e=ht(t.style.getPropertyValue(R).trim());e&&t.style.setProperty(_,pt(e,gt()))}function qt(){if(!b)return;const t=b;b=null,t.isConnected&&(t.classList.remove(H),t.removeAttribute("data-tldr-deemphasize"),t.style.removeProperty(R),t.style.removeProperty(_))}function xt(){st||(st=!0,chrome.storage.sync.get([k,w,B],t=>{z=$(t==null?void 0:t[k]),v=P(t==null?void 0:t[w]),U=Q(t==null?void 0:t[B]),rt(),N(document.getElementById(y)),G()}),chrome.storage.onChanged.addListener((t,e)=>{if(e!=="sync")return;const s=t==null?void 0:t[B];s!==void 0&&(U=Q(s.newValue),G());const r=t==null?void 0:t[k];if(!r){const i=t==null?void 0:t[w];i&&(v=P(i.newValue),N(document.getElementById(y)));return}z=$(r.newValue),rt();const n=t==null?void 0:t[w];n&&(v=P(n.newValue),N(document.getElementById(y)))}))}function Dt(t){return t.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function $t(t,e,s){const r=[];g=[];let n=0;for(const i of s){const o=i.trim();if(!o)continue;const a=t.indexOf(o,n);if(a===-1)continue;const c=a,d=a+o.length,f=A(e,c,d);f&&(r.push(f),g.push({sentence:o,range:f,start:c,end:d}),n=d)}return r}function Ft(t,e,s){const r=[];g=[];const n=Array.from(new Set(s.map(a=>a.trim()).filter(Boolean).map(a=>a.toLowerCase())));if(!n.length)return r;const i=new RegExp(`\\b(${n.map(Dt).join("|")})\\b`,"gi");let o;for(;o=i.exec(t);){const a=o[0],c=o.index,d=o.index+a.length,f=A(e,c,d);f&&(r.push(f),g.push({sentence:a,range:f,start:c,end:d}))}return r}function Vt(t){return typeof t=="object"&&t!==null&&"start"in t&&"end"in t}function ot(t){return t.replace(/\s+/g," ").trim()}function T(t,e,s){if(!e)return null;let r=null,n=t.indexOf(e);for(;n!==-1;)(r===null||Math.abs(n-s)<Math.abs(r-s))&&(r=n),n=t.indexOf(e,n+1);return r}function zt(t,e){const s=Math.max(0,Math.min(t.length,e.start)),r=Math.max(0,Math.min(t.length,e.end));if(r<=s)return null;const n=ot(t.slice(s,r)),i=ot(e.text);if(n&&i&&n===i)return{start:s,end:r};const o=256,a=Math.max(0,s-o),c=Math.min(t.length,s+o+e.text.length),d=t.slice(a,c),f=T(d,e.text,s-a);if(f!==null)return{start:a+f,end:a+f+e.text.length};const x=T(d.toLowerCase(),e.text.toLowerCase(),s-a);if(x!==null)return{start:a+x,end:a+x+e.text.length};const l=T(t,e.text,s);if(l!==null)return{start:l,end:l+e.text.length};const u=T(t.toLowerCase(),e.text.toLowerCase(),s);return u!==null?{start:u,end:u+e.text.length}:null}function Ut(t,e,s){const r=[];return g=[],s.forEach(n=>{const i=zt(t,n);if(!i)return;const o=i.start,a=i.end,c=A(e,o,a);c&&(r.push(c),g.push({sentence:t.slice(o,a),range:c,start:o,end:a}))}),r}function mt(t){const e=t instanceof Element?t:t.parentElement;return!!(e!=null&&e.closest("input, textarea, [contenteditable='true']"))}function Gt(){var s;const t=[...g].sort((r,n)=>n.start-r.start),e=[];for(const r of t){if(mt(r.range.commonAncestorContainer))continue;const n=document.createElement("span");n.className=lt,n.setAttribute(J,"true");try{const i=r.range.extractContents();if(!((s=i.textContent)!=null&&s.trim()))continue;n.appendChild(i),r.range.insertNode(n);const o=document.createRange();o.selectNodeContents(n),e.push({...r,range:o})}catch{}}return e.sort((r,n)=>r.start-n.start),g=e,g.length}function bt(t,e){if(ft(),!t.length)return 0;xt(),dt();const s=K(document),{text:r,nodes:n}=W(s);C=n;const i=t.filter(Boolean);m("cs","applyHighlights start",{requested:i.length,type:e,textLen:r.length,nodes:n.length});let o=[];if(e==="keywords"){const a=i.filter(Vt);if(a.length)o=Ut(r,n,a);else{const c=i.filter(d=>typeof d=="string");o=Ft(r,n,c)}}else{const a=i.filter(c=>typeof c=="string");o=$t(r,n,a)}if(e==="keywords")if(Pt(s),"highlights"in CSS){m("cs","applyHighlights using CSS Custom Highlight API (keywords)",{ranges:o.length});const a=new Highlight(...o);CSS.highlights.set(j,a)}else F("cs","applyHighlights using embolden mode fallback (DOM mutation)"),Gt();else if("highlights"in CSS){m("cs","applyHighlights using CSS Custom Highlight API",{ranges:o.length});const a=new Highlight(...o);CSS.highlights.set(Y,a)}else F("cs","applyHighlights using mark fallback (DOM mutation)"),o.forEach(a=>{const c=document.createElement("mark");c.setAttribute(at,"true");try{a.surroundContents(c)}catch{}});return m("cs","applyHighlights done",{applied:g.length}),g.length}function Kt(t){if(!g.length)return null;const e=t.target;if(e&&(e.closest("input")||e.closest("textarea")||e.closest("[contenteditable='true']")))return null;const s=document.caretRangeFromPoint?document.caretRangeFromPoint(t.clientX,t.clientY):(()=>{var i;const r=(i=document.caretPositionFromPoint)==null?void 0:i.call(document,t.clientX,t.clientY);if(!r)return null;const n=document.createRange();return n.setStart(r.offsetNode,r.offset),n.setEnd(r.offsetNode,r.offset),n})();if(!s)return null;for(const r of g)if(r.range.isPointInRange(s.startContainer,s.startOffset))return r;return null}function Wt(t){var o;(o=document.getElementById(Ot))==null||o.remove();const e=Kt(t);if(!e)return;const s=e.range.cloneRange(),n=Ht(C,s)?s.toString():e.sentence,i={type:"HighlightClicked",requestId:it("highlight"),sentence:e.sentence,context:n};m("cs","HighlightClicked",{sentenceLen:e.sentence.length,contextLen:n.length}),chrome.runtime.sendMessage(i,()=>void chrome.runtime.lastError),L("cs","HighlightClicked sendMessage")}function Yt(t){var e;if(t.type==="ExtractRequest"){const s=K(document),{text:r}=W(s),n=yt(r),i=n.find(a=>a.trim().length>0)??"";m("cs","ExtractRequest",{requestId:t.requestId,root:s.tagName,textLen:r.length,sentences:n.length,firstSentence:i});const o={type:"ExtractResult",requestId:t.requestId,tabId:t.tabId,text:r,sentences:n};chrome.runtime.sendMessage(o,()=>void chrome.runtime.lastError),L("cs","ExtractResult sendMessage")}if(t.type==="ApplyHighlightsRequest"){m("cs","ApplyHighlightsRequest",{requestId:t.requestId,highlights:((e=t.highlights)==null?void 0:e.length)??0,type:t.highlightType});const s=bt(t.highlights,t.highlightType);chrome.runtime.sendMessage({type:"ApplyHighlightsAck",requestId:t.requestId,tabId:t.tabId,count:s},()=>void chrome.runtime.lastError),L("cs","ApplyHighlightsAck sendMessage")}t.type==="ApplyRsvpCursorRequest"&&(m("cs","ApplyRsvpCursorRequest",{requestId:t.requestId,start:t.start,end:t.end,scroll:!!t.scrollIntoView}),_t(t.start,t.end,!!t.scrollIntoView,t.word)),t.type==="ClearRsvpCursorRequest"&&(m("cs","ClearRsvpCursorRequest",{requestId:t.requestId}),ut())}chrome.runtime.onMessage.addListener(t=>{m("cs","onMessage",{type:t==null?void 0:t.type,requestId:t==null?void 0:t.requestId}),Yt(t)});document.addEventListener("click",Wt,{capture:!0});xt();I();Bt();Mt();
