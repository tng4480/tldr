import{s as gt,H as k,E as I,c as B,n as _,w as xt,d as mt,D as bt,e as yt,a as Ct}from"./settings-DOArjBjZ.js";import{l as m,r as H,c as nt,w as D}from"./logger-Oy_tsM0_.js";var Et=["article","main","[role='main']",".article",".post",".content"],St=["script","style","noscript","textarea","input","select","option","button","code","pre","[contenteditable='true']"];function Rt(t){return t?t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement?!0:t instanceof HTMLElement?t.isContentEditable:!1:!1}function z(t){for(const e of Et){const n=t.querySelector(e);if(n&&n.textContent&&n.textContent.trim().length>200)return n}return t.body}function wt(t){const e=[],n=[],s=(t.ownerDocument??document).createTreeWalker(t,NodeFilter.SHOW_TEXT,{acceptNode(l){if(!l.nodeValue||!l.nodeValue.trim())return NodeFilter.FILTER_REJECT;const u=l.parentElement;return!u||St.some(f=>u.closest(f))||Rt(u)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}});let i=s.nextNode(),o=0,a=!1,c=!1,d=!1;function h(){!c||a||(n.push(" "),o+=1,a=!0)}function x(l,u,f){const p=e[e.length-1];p&&p.node===l&&p.end===o&&p.nodeOffset+(p.end-p.start)===u?p.end+=1:e.push({node:l,start:o,end:o+1,nodeOffset:u}),n.push(f),o+=1,a=!1,c=!0}for(;i;){const l=i,u=l.nodeValue??"";if(u.length>0){e.length>0&&(d=!0);for(let f=0;f<u.length;f+=1){const p=u[f]??"";if(/\s/.test(p)){d=!0;continue}d&&(h(),d=!1),x(l,f,p)}d=!0}i=s.nextNode()}return a&&n.length>0&&n[n.length-1]===" "&&n.pop(),{text:n.join(""),nodes:e}}function G(t){return wt(t)}function M(t,e,n){var c,d,h,x;if(!t.length)return null;const r=((d=(c=t[0])==null?void 0:c.node.ownerDocument)==null?void 0:d.createRange())??document.createRange();let s,i;for(const l of t)if(!s&&e>=l.start&&e<l.end&&(s=l),n>l.start&&n<=l.end){i=l;break}if(s||(s=t.find(l=>l.start>e),e=(s==null?void 0:s.start)??e),!i)for(let l=t.length-1;l>=0;l-=1){const u=t[l];if(n>=u.end){i=u,n=u.end;break}}if(!s||!i)return null;const o=Math.max(0,s.nodeOffset+(e-s.start)),a=Math.max(0,i.nodeOffset+(n-i.start));return r.setStart(s.node,Math.min(o,((h=s.node.nodeValue)==null?void 0:h.length)??o)),r.setEnd(i.node,Math.min(a,((x=i.node.nodeValue)==null?void 0:x.length)??a)),r}function It(t,e){const n=e.startContainer,r=e.endContainer;if(!(n instanceof Text)||!(r instanceof Text))return null;const s=t.find(o=>o.node===n&&e.startOffset>=o.nodeOffset&&e.startOffset<=o.nodeOffset+(o.end-o.start)),i=t.find(o=>o.node===r&&e.endOffset>=o.nodeOffset&&e.endOffset<=o.nodeOffset+(o.end-o.start));return!s||!i?null:{start:s.start+(e.startOffset-s.nodeOffset),end:i.start+(e.endOffset-i.nodeOffset)}}const U="tldr-highlight-sentences",K="tldr-highlight-keywords",W="tldr-highlight-rsvp-cursor",st="data-tldr-highlight",Tt="tldr-inline-popover",y="tldr-floating-bubble",j="data-tldr-embolden",rt="tldr-embolden",Y="data-tldr-rsvp-cursor",ot="tldr-rsvp-cursor",O="tldr-deemphasize",A="--tldr-deemphasis-color",R="--tldr-base-color",X=200;let E=[],C="",L=0,g=[],P=null,q=null,J=!1,b=null,Z=!1,$=!1,F=Ct,v=bt,Q=!1,S=null;function vt(){const t={type:"ContentReady",requestId:nt("content-ready")};m("cs","ContentReady",{href:location.href}),chrome.runtime.sendMessage(t,()=>H("cs","ContentReady sendMessage"))}function Nt(){q&&window.clearTimeout(q),q=window.setTimeout(()=>{w()},750)}function w(){const t=z(document),{text:e,nodes:n}=G(t);E=n,C=e,L=xt(e),m("cs","refreshNodes",{nodes:E.length,root:t.tagName,words:L}),Lt()}function it(){if(J)return;const t=document.createElement("style");t.textContent=`
    ::highlight(${U}) {
      background-color: rgba(249, 116, 75, 0.28);
    }

    ::highlight(${K}) {
      background-color: transparent;
      color: var(${R});
      text-shadow: 0.35px 0 0 currentColor, -0.35px 0 0 currentColor;
    }

    ::highlight(${W}) {
      background-color: rgba(249, 116, 75, 0.22);
      text-decoration: underline;
      text-decoration-thickness: 2px;
      text-decoration-color: rgba(249, 116, 75, 0.85);
      text-underline-offset: 2px;
    }

    .${rt}[${j}] {
      color: var(${R});
      text-shadow: 0.35px 0 0 currentColor, -0.35px 0 0 currentColor;
    }

    .${ot}[${Y}] {
      position: relative;
      background-color: rgba(249, 116, 75, 0.22);
      border-radius: 3px;
    }

    .${O},
    .${O} * {
    color: var(${A});
    }
  `,document.head.appendChild(t),J=!0}function at(){"highlights"in CSS&&CSS.highlights.delete(W);const t=[];S?t.push(S):"highlights"in CSS||t.push(...document.querySelectorAll(`span[${Y}]`)),t.forEach(e=>{e.isConnected&&e.replaceWith(...e.childNodes)}),S=null}function Ht(t,e,n,r){at(),it(),(!C||!E.length||e>C.length)&&w(),r&&C.slice(t,e)!==r&&w();const s=M(E,t,e);if(s&&!ft(s.commonAncestorContainer)){if(n){const i=s.getBoundingClientRect();if(i.top<0||i.bottom>window.innerHeight){const o=s.startContainer instanceof Element?s.startContainer:s.startContainer.parentElement;o==null||o.scrollIntoView({block:"center",inline:"nearest"})}}if("highlights"in CSS)CSS.highlights.set(W,new Highlight(s));else{const i=document.createElement("span");i.className=ot,i.setAttribute(Y,"true");try{s.surroundContents(i),S=i}catch{S=null}}}}function N(t){if(!t)return;const e=mt(v);t.style.setProperty("--assist-ext-bg",e.bg),t.style.setProperty("--assist-ext-surface",e.surface),t.style.setProperty("--assist-ext-bg-elevated",e.surface),t.style.setProperty("--assist-ext-surface-soft",`${e.surface}cc`),t.style.setProperty("--assist-ext-border",e.border),t.style.setProperty("--assist-ext-border-soft",`${e.border}99`),t.style.setProperty("--assist-ext-text",e.text),t.style.setProperty("--assist-ext-muted",e.muted),t.style.setProperty("--assist-ext-accent",e.accent),t.style.setProperty("--assist-ext-danger",e.danger)}function Ot(){if(Z||!document.body)return;const t=document.createElement("div");t.id=y,t.style.position="fixed",t.style.zIndex="2147483647",t.style.right="18px",t.style.bottom="18px",t.style.display="none",t.style.pointerEvents="auto",document.body.appendChild(t),N(t);const e=t.attachShadow({mode:"open"}),n=document.createElement("style");n.textContent=`
    :host { all: initial; }
    :host {
      --assist-ext-bg: #0a1523;
      --assist-ext-bg-elevated: #193552;
      --assist-ext-surface: #193552cc;
      --assist-ext-border: #2f587f;
      --assist-ext-border-soft: #2f587f99;
      --assist-ext-text: #e0eaf4;
      --assist-ext-muted: #97b1cc;
      --assist-ext-accent: #2f5e8d;
      --assist-ext-radius: 16px;
    }
    .assist-ext-wrap {
      font-family: "Bahnschrift", "Trebuchet MS", "Gill Sans MT", "Segoe UI", sans-serif;
      color: var(--assist-ext-text);
      line-height: 1.45;
    }
    .assist-ext-bubble {
      width: 40px;
      height: 40px;
      border-radius: 14px;
      border: 1px solid var(--assist-ext-border-soft);
      background: color-mix(in srgb, #071a31 74%, transparent);
      color: var(--assist-ext-text);
      cursor: pointer;
      display: grid;
      place-items: center;
      user-select: none;
      font-weight: 600;
      font-size: 12px;
      backdrop-filter: blur(14px);
      box-shadow: 0 16px 34px rgba(1, 10, 24, 0.42);
      transition: transform 120ms ease, box-shadow 120ms ease, border-color 120ms ease, background 120ms ease;
    }
    .assist-ext-bubble img {
      width: 22px;
      height: 22px;
      object-fit: contain;
      display: block;
      pointer-events: none;
    }
    .assist-ext-bubble:hover {
      box-shadow:
        0 0 0 3px color-mix(in srgb, var(--assist-ext-accent) 24%, transparent),
        0 18px 38px rgba(1, 10, 24, 0.5);
    }
    .assist-ext-bubble:active {
      transform: translateY(1px);
      box-shadow:
        inset 0 1px 0 rgba(255, 255, 255, 0.1),
        0 10px 22px rgba(1, 10, 24, 0.32);
    }
    .assist-ext-panel {
      position: absolute;
      right: 0;
      bottom: 52px;
      width: 296px;
      border-radius: calc(var(--assist-ext-radius) + 2px);
      border: 1px solid var(--assist-ext-border-soft);
      background:
        radial-gradient(circle at 0% 0%, color-mix(in srgb, var(--assist-ext-accent) 18%, transparent), transparent 44%),
        linear-gradient(180deg, #0f253d 0%, var(--assist-ext-bg) 52%);
      color: var(--assist-ext-text);
      padding: 12px;
      display: none;
      backdrop-filter: blur(16px);
      box-shadow: 0 24px 52px rgba(1, 10, 24, 0.5);
    }
    .assist-ext-row { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
    .assist-ext-title {
      font-family: "Franklin Gothic Medium", "Arial Narrow", "Trebuchet MS", sans-serif;
      font-weight: 600;
      font-size: 13px;
      letter-spacing: 0.06em;
      text-transform: uppercase;
    }
    .assist-ext-meta { color: var(--assist-ext-muted); font-size: 12px; }
    .assist-ext-btn-row { display: flex; gap: 8px; margin-top: 10px; flex-wrap: wrap; }
    .assist-ext-button {
      border-radius: 999px;
      border: 1px solid var(--assist-ext-border-soft);
      background: color-mix(in srgb, var(--assist-ext-bg-elevated) 62%, transparent);
      color: var(--assist-ext-text);
      padding: 6px 10px;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 8px 18px rgba(0, 0, 0, 0.24);
      transition: transform 120ms ease, box-shadow 120ms ease, border-color 120ms ease, background 120ms ease;
    }
    .assist-ext-button:hover {
      box-shadow:
        0 0 0 3px color-mix(in srgb, var(--assist-ext-accent) 24%, transparent),
        0 12px 26px rgba(1, 10, 24, 0.36);
    }
    .assist-ext-button:active {
      transform: translateY(1px);
      box-shadow:
        inset 0 1px 0 rgba(255, 255, 255, 0.1),
        0 6px 14px rgba(1, 10, 24, 0.28);
    }
    .assist-ext-button:focus-visible {
      outline: 2px solid color-mix(in srgb, var(--assist-ext-accent) 84%, white);
      outline-offset: 2px;
    }
    .assist-ext-button--primary {
      border-color: color-mix(in srgb, var(--assist-ext-accent) 68%, #b8e8ff);
      color: var(--assist-ext-accent);
      font-weight: 600;
    }
  `;const r=document.createElement("div");r.className="assist-ext-wrap";const s=document.createElement("div");s.className="assist-ext-panel",s.setAttribute("role","dialog"),s.setAttribute("aria-label","TLDR reading assistant");const i=document.createElement("div");i.className="assist-ext-row";const o=document.createElement("div");o.className="assist-ext-title",o.textContent="TLDR";const a=document.createElement("button");a.className="assist-ext-button",a.textContent="Close",a.addEventListener("click",f=>{f.preventDefault(),f.stopPropagation(),V(!1)}),i.append(o,a);const c=document.createElement("div");c.className="assist-ext-meta",c.id="tldr-bubble-meta",c.textContent="Detecting page text...";const d=document.createElement("div");d.className="assist-ext-btn-row";const h=document.createElement("button");h.className="assist-ext-button assist-ext-button--primary",h.textContent="Highlight key phrases",h.addEventListener("click",f=>{f.preventDefault(),f.stopPropagation();try{C.trim()||w();const p=yt(C);pt(p,"keywords")}catch(p){D("cs","Bubble highlight failed",p)}});const x=document.createElement("button");x.className="assist-ext-button",x.textContent="Clear highlights",x.addEventListener("click",f=>{f.preventDefault(),f.stopPropagation(),lt()}),d.append(h,x),s.append(i,c,d);const l=document.createElement("button");l.className="assist-ext-bubble",l.setAttribute("aria-label","Open TLDR");const u=document.createElement("img");u.alt="",u.src=chrome.runtime.getURL("tldr.png"),l.appendChild(u),l.addEventListener("click",f=>{f.preventDefault(),f.stopPropagation(),V(!$)}),r.append(s,l),e.append(n,r),Z=!0}function V(t){var r;$=t;const e=document.getElementById(y),n=(r=e==null?void 0:e.shadowRoot)==null?void 0:r.querySelector(".assist-ext-panel");n&&(n.style.display=$?"block":"none")}function Lt(){var r;Ot();const t=document.getElementById(y);if(!t)return;const e=L>=X;t.style.display=e?"block":"none",e||V(!1);const n=(r=t.shadowRoot)==null?void 0:r.getElementById("tldr-bubble-meta");n&&(n.textContent=e?`${L.toLocaleString()} words detected on this page.`:`Needs ${X}+ words to show.`)}function Mt(){P||(P=new MutationObserver(()=>{Nt()}),P.observe(document.body,{childList:!0,subtree:!0}),m("cs","MutationObserver attached"))}function lt(){g=[],kt(),"highlights"in CSS&&(CSS.highlights.delete(U),CSS.highlights.delete(K)),document.querySelectorAll(`mark[${st}], span[${j}]`).forEach(t=>t.replaceWith(...t.childNodes))}function ct(t){const e=t.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*,\s*([0-9.]+))?\s*\)/i);if(!e)return null;const n=Number.parseInt(e[1]??"",10),r=Number.parseInt(e[2]??"",10),s=Number.parseInt(e[3]??"",10),i=e[4]!==void 0?Number.parseFloat(e[4]):1;return[n,r,s,i].some(o=>Number.isNaN(o))?null:{r:n,g:r,b:s,a:i}}function dt(t,e){const n=Math.max(0,Math.min(1,e)),r=t.r*.2126+t.g*.7152+t.b*.0722,s=Math.round(Math.max(0,Math.min(255,r*.4+128*.6))),i=Math.round(t.r*(1-n)+s*n),o=Math.round(t.g*(1-n)+s*n),a=Math.round(t.b*(1-n)+s*n);return`rgba(${i}, ${o}, ${a}, ${t.a})`}function ut(){return B(F)/100}function At(t){const e=window.getComputedStyle(t),n=ct(e.color);if(!n)return;const r=`rgba(${n.r}, ${n.g}, ${n.b}, ${n.a})`,s=dt(n,ut());t.classList.add(O),t.setAttribute("data-tldr-deemphasize","true"),t.style.setProperty(R,r),t.style.setProperty(A,s),b=t}function tt(){if(!b)return;const t=b;if(!t.isConnected){b=null;return}const e=ct(t.style.getPropertyValue(R).trim());e&&t.style.setProperty(A,dt(e,ut()))}function kt(){if(!b)return;const t=b;b=null,t.isConnected&&(t.classList.remove(O),t.removeAttribute("data-tldr-deemphasize"),t.style.removeProperty(R),t.style.removeProperty(A))}function ht(){Q||(Q=!0,chrome.storage.sync.get([k,I],t=>{F=B(t==null?void 0:t[k]),v=_(t==null?void 0:t[I]),tt(),N(document.getElementById(y))}),chrome.storage.onChanged.addListener((t,e)=>{if(e!=="sync")return;const n=t==null?void 0:t[k];if(!n){const s=t==null?void 0:t[I];s&&(v=_(s.newValue),N(document.getElementById(y)));return}F=B(n.newValue),tt();const r=t==null?void 0:t[I];r&&(v=_(r.newValue),N(document.getElementById(y)))}))}function _t(t){return t.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function Pt(t,e,n){const r=[];g=[];let s=0;for(const i of n){const o=i.trim();if(!o)continue;const a=t.indexOf(o,s);if(a===-1)continue;const c=a,d=a+o.length,h=M(e,c,d);h&&(r.push(h),g.push({sentence:o,range:h,start:c,end:d}),s=d)}return r}function qt(t,e,n){const r=[];g=[];const s=Array.from(new Set(n.map(a=>a.trim()).filter(Boolean).map(a=>a.toLowerCase())));if(!s.length)return r;const i=new RegExp(`\\b(${s.map(_t).join("|")})\\b`,"gi");let o;for(;o=i.exec(t);){const a=o[0],c=o.index,d=o.index+a.length,h=M(e,c,d);h&&(r.push(h),g.push({sentence:a,range:h,start:c,end:d}))}return r}function Bt(t){return typeof t=="object"&&t!==null&&"start"in t&&"end"in t}function et(t){return t.replace(/\s+/g," ").trim()}function T(t,e,n){if(!e)return null;let r=null,s=t.indexOf(e);for(;s!==-1;)(r===null||Math.abs(s-n)<Math.abs(r-n))&&(r=s),s=t.indexOf(e,s+1);return r}function Dt(t,e){const n=Math.max(0,Math.min(t.length,e.start)),r=Math.max(0,Math.min(t.length,e.end));if(r<=n)return null;const s=et(t.slice(n,r)),i=et(e.text);if(s&&i&&s===i)return{start:n,end:r};const o=256,a=Math.max(0,n-o),c=Math.min(t.length,n+o+e.text.length),d=t.slice(a,c),h=T(d,e.text,n-a);if(h!==null)return{start:a+h,end:a+h+e.text.length};const x=T(d.toLowerCase(),e.text.toLowerCase(),n-a);if(x!==null)return{start:a+x,end:a+x+e.text.length};const l=T(t,e.text,n);if(l!==null)return{start:l,end:l+e.text.length};const u=T(t.toLowerCase(),e.text.toLowerCase(),n);return u!==null?{start:u,end:u+e.text.length}:null}function $t(t,e,n){const r=[];return g=[],n.forEach(s=>{const i=Dt(t,s);if(!i)return;const o=i.start,a=i.end,c=M(e,o,a);c&&(r.push(c),g.push({sentence:t.slice(o,a),range:c,start:o,end:a}))}),r}function ft(t){const e=t instanceof Element?t:t.parentElement;return!!(e!=null&&e.closest("input, textarea, [contenteditable='true']"))}function Ft(){var n;const t=[...g].sort((r,s)=>s.start-r.start),e=[];for(const r of t){if(ft(r.range.commonAncestorContainer))continue;const s=document.createElement("span");s.className=rt,s.setAttribute(j,"true");try{const i=r.range.extractContents();if(!((n=i.textContent)!=null&&n.trim()))continue;s.appendChild(i),r.range.insertNode(s);const o=document.createRange();o.selectNodeContents(s),e.push({...r,range:o})}catch{}}return e.sort((r,s)=>r.start-s.start),g=e,g.length}function pt(t,e){if(lt(),!t.length)return 0;ht(),it();const n=z(document),{text:r,nodes:s}=G(n);E=s;const i=t.filter(Boolean);m("cs","applyHighlights start",{requested:i.length,type:e,textLen:r.length,nodes:s.length});let o=[];if(e==="keywords"){const a=i.filter(Bt);if(a.length)o=$t(r,s,a);else{const c=i.filter(d=>typeof d=="string");o=qt(r,s,c)}}else{const a=i.filter(c=>typeof c=="string");o=Pt(r,s,a)}if(e==="keywords")if(At(n),"highlights"in CSS){m("cs","applyHighlights using CSS Custom Highlight API (keywords)",{ranges:o.length});const a=new Highlight(...o);CSS.highlights.set(K,a)}else D("cs","applyHighlights using embolden mode fallback (DOM mutation)"),Ft();else if("highlights"in CSS){m("cs","applyHighlights using CSS Custom Highlight API",{ranges:o.length});const a=new Highlight(...o);CSS.highlights.set(U,a)}else D("cs","applyHighlights using mark fallback (DOM mutation)"),o.forEach(a=>{const c=document.createElement("mark");c.setAttribute(st,"true");try{a.surroundContents(c)}catch{}});return m("cs","applyHighlights done",{applied:g.length}),g.length}function Vt(t){if(!g.length)return null;const e=t.target;if(e&&(e.closest("input")||e.closest("textarea")||e.closest("[contenteditable='true']")))return null;const n=document.caretRangeFromPoint?document.caretRangeFromPoint(t.clientX,t.clientY):(()=>{var i;const r=(i=document.caretPositionFromPoint)==null?void 0:i.call(document,t.clientX,t.clientY);if(!r)return null;const s=document.createRange();return s.setStart(r.offsetNode,r.offset),s.setEnd(r.offsetNode,r.offset),s})();if(!n)return null;for(const r of g)if(r.range.isPointInRange(n.startContainer,n.startOffset))return r;return null}function zt(t){var o;(o=document.getElementById(Tt))==null||o.remove();const e=Vt(t);if(!e)return;const n=e.range.cloneRange(),s=It(E,n)?n.toString():e.sentence,i={type:"HighlightClicked",requestId:nt("highlight"),sentence:e.sentence,context:s};m("cs","HighlightClicked",{sentenceLen:e.sentence.length,contextLen:s.length}),chrome.runtime.sendMessage(i,()=>void chrome.runtime.lastError),H("cs","HighlightClicked sendMessage")}function Gt(t){var e;if(t.type==="ExtractRequest"){const n=z(document),{text:r}=G(n),s=gt(r),i=s.find(a=>a.trim().length>0)??"";m("cs","ExtractRequest",{requestId:t.requestId,root:n.tagName,textLen:r.length,sentences:s.length,firstSentence:i});const o={type:"ExtractResult",requestId:t.requestId,tabId:t.tabId,text:r,sentences:s};chrome.runtime.sendMessage(o,()=>void chrome.runtime.lastError),H("cs","ExtractResult sendMessage")}if(t.type==="ApplyHighlightsRequest"){m("cs","ApplyHighlightsRequest",{requestId:t.requestId,highlights:((e=t.highlights)==null?void 0:e.length)??0,type:t.highlightType});const n=pt(t.highlights,t.highlightType);chrome.runtime.sendMessage({type:"ApplyHighlightsAck",requestId:t.requestId,tabId:t.tabId,count:n},()=>void chrome.runtime.lastError),H("cs","ApplyHighlightsAck sendMessage")}t.type==="ApplyRsvpCursorRequest"&&(m("cs","ApplyRsvpCursorRequest",{requestId:t.requestId,start:t.start,end:t.end,scroll:!!t.scrollIntoView}),Ht(t.start,t.end,!!t.scrollIntoView,t.word)),t.type==="ClearRsvpCursorRequest"&&(m("cs","ClearRsvpCursorRequest",{requestId:t.requestId}),at())}chrome.runtime.onMessage.addListener(t=>{m("cs","onMessage",{type:t==null?void 0:t.type,requestId:t==null?void 0:t.requestId}),Gt(t)});document.addEventListener("click",zt,{capture:!0});ht();w();Mt();vt();
