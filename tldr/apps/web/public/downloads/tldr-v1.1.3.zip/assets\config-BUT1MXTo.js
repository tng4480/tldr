function e(){const r="https://tldr-321914.vercel.app/".trim();if(r)return r.replace(/\/+$/,"");throw new Error("VITE_API_BASE_URL is required for production builds.")}export{e as g};
